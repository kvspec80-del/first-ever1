// Optimerar bilder: lägg originalfoton (jpg/png) i /raw och kör `npm run images`.
// Skapar WebP i flera bredder i /public/images och uppdaterar src/lib/image-meta.ts.
import sharp from 'sharp'; import fs from 'fs'; import path from 'path';
const [src, dst] = process.argv.slice(2); const meta = {};
for (const f of fs.readdirSync(src)) {
  const n = path.parse(f).name; const img = sharp(path.join(src, f)); const m = await img.metadata();
  const widths = n === 'hero' || n === 'booking' ? [640, 1200, 1920, 2400] : [640, 1200, 1920];
  for (const w of widths) await sharp(path.join(src, f)).resize({ width: Math.min(w, m.width) }).webp({ quality: 72 }).toFile(path.join(dst, `${n}-${w}.webp`));
  meta[n] = { w: m.width, h: m.height, widths };
}
// Skriv typad metadata som komponenterna använder (bredd/höjd = ingen layoutförskjutning)
const lines = Object.entries(meta).sort().map(([k, v]) => `  "${k}": { width: ${v.w}, height: ${v.h}, widths: [${v.widths.join(", ")}] },`);
fs.writeFileSync('src/lib/image-meta.ts', `// Genererad av scripts/optimize-images.mjs – redigera inte för hand.\nexport const imageMeta = {\n${lines.join("\n")}\n} as const;\n`);
