import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Statisk export: `npm run build` skapar mappen /out som kan läggas på valfritt webbhotell.
  // Ta bort raden om ni hellre kör på Vercel/Node-server.
  output: "export",
  reactStrictMode: true,
  poweredByHeader: false,
};

export default nextConfig;
