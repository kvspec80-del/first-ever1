# LeilasBar – webbplats

Webbplats för LeilasBar, köksbar & restaurang på Elementvägen 1 i Lindome. Byggd med **Next.js 16 (App Router)**, **React 19**, **Tailwind CSS 4** och **Lucide-ikoner**.

## Kom igång

```bash
npm install
npm run dev        # http://localhost:3000
npm run build      # statisk export till /out – ladda upp till valfritt webbhotell
```

Kräver Node.js 20.9 eller senare (se `.nvmrc`).

## Publicera (deploy)

Sidan byggs som statiska filer och kan ligga hos vilken webbhost som helst. Enklast:

**Vercel (rekommenderas, gratis för en sådan här sida)**
1. Logga in på [vercel.com](https://vercel.com) med ditt GitHub-konto.
2. *Add New → Project* → välj repot `leilasbar` → *Deploy*. Inga inställningar behövs.
3. Under *Settings → Domains* lägger du till `leilasbar.se` och följer instruktionerna för DNS hos er domänleverantör.

Varje gång något pushas till `main` publiceras sidan automatiskt.

**Netlify / Cloudflare Pages** fungerar också: byggkommando `npm run build`, publiceringsmapp `out`.

**Eget webbhotell (FTP):** kör `npm run build` och ladda upp innehållet i mappen `out/`.

GitHub Actions (`.github/workflows/ci.yml`) bygger och typkontrollerar sidan vid varje push, så att fel upptäcks innan de publiceras.

Glöm inte att uppdatera `url` i `src/config/site.ts` om sidan får en annan adress än `https://www.leilasbar.se`.

## Fyll i restaurangens uppgifter

Allt som är markerat med `[HAKPARENTESER]` är platshållare.

| Vad | Fil |
| --- | --- |
| Namn, telefon, adress, öppettider, Instagram/Facebook, Google Maps, domän | `src/config/site.ts` |
| Kvällsmenyn (rätter, priser, bilder) | `src/data/menu.ts` |
| "Det händer hos oss" – evenemang, julbord, säsongsmenyer | `src/data/events.ts` |
| Galleriet | `src/data/gallery.ts` |
| "Sedan [ÅR]" i introduktionen | `src/components/Intro.tsx` |

**Telefonnummer:** fyll i både `phone.display` (som visas, t.ex. `08-123 456 78`) och `phone.href` (för tel:-länken, t.ex. `+46812345678`). Alla "Boka bord"-knappar använder det automatiskt.

**Karta:** öppna restaurangen i Google Maps → Dela → Bädda in karta → kopiera `src`-adressen till `mapEmbedUrl`.

**Evenemang:** lägg till ett nytt objekt i listan i `events.ts`. Sätt `visible: false` för att dölja ett evenemang utan att radera det. Det första visas störst.

## Bilder

Bilderna kommer från Unsplash (fri licens) och fungerar som stämningsbilder tills ni har egna foton. Använd gärna egna bilder på era rätter och lokalen.

1. Lägg originalfoton i mappen `raw/` med samma filnamn som i `src/lib/image-meta.ts` (t.ex. `raw/plankstek.jpg`) – eller nya namn.
2. Kör `npm run images`. Då skapas WebP-filer i flera storlekar i `public/images/` och `src/lib/image-meta.ts` uppdateras.
3. Använder du nya namn behöver du också byta bildnamnet i `menu.ts`, `events.ts` eller `gallery.ts`.

## Struktur

```
src/
  app/            layout (SEO, typsnitt, JSON-LD), sida, robots, sitemap, ikon, globala stilar
  components/     Navbar, Hero, Intro, MenuSection, Events, Gallery, About, Booking, Contact, Footer, MobileBookBar
  components/ui/  Picture (responsiva bilder), Reveal (scrollanimation), SectionHeading, Button
  config/site.ts  restaurangens uppgifter
  data/           meny, evenemang, galleri
preview/          bygger en fristående HTML-demo (behövs inte för produktion)
```

## Inbyggt

- Transparent navigering över hero som blir solid vid scroll, aktiv-markering och tillgänglig mobilmeny (Esc, fokus, scroll-lås)
- Fast "Boka bord"-knapp på mobil, plus bokningsknappar i nav, hero, meny och bokningssektion – alla med `tel:`-länk
- Responsiva WebP-bilder med `srcset`, lazy loading och fasta dimensioner (ingen layoutförskjutning)
- SEO: metadata, Open Graph, `lang="sv"`, schema.org `Restaurant` + meny som JSON-LD, sitemap och robots
- Galleri med ljusbox (piltangenter och Esc)
- Diskreta scrollanimationer som respekterar "minska rörelse" och fungerar utan JavaScript
