// Fristående förhandsvisning (utan Next.js-server) – används bara för att bygga en delbar demo.
import { createRoot } from "react-dom/client";
import { HomePage } from "@/components/HomePage";

document.documentElement.classList.add("js");
createRoot(document.getElementById("root")!).render(<HomePage />);
