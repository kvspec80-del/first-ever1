// Bygger en fristående HTML-förhandsvisning till preview/dist (node preview/build.mjs)
import { build } from "esbuild";
import { execSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "..");
const dist = path.join(root, "preview/dist");
fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(path.join(dist, "images"), { recursive: true });

const js = await build({
  entryPoints: [path.join(root, "preview/main.tsx")],
  bundle: true, minify: true, write: false, format: "iife", jsx: "automatic", target: "es2020",
  alias: { "@": path.join(root, "src") },
  define: { "process.env.NEXT_PUBLIC_IMAGE_BASE": '"images"', "process.env.NODE_ENV": '"production"' },
});
execSync(`npx @tailwindcss/cli -i src/app/globals.css -o preview/dist/_app.css --minify`, { cwd: root, stdio: "inherit" });
const css = fs.readFileSync(path.join(dist, "_app.css"), "utf8");
fs.rmSync(path.join(dist, "_app.css"));

for (const f of fs.readdirSync(path.join(root, "public/images"))) {
  fs.copyFileSync(path.join(root, "public/images", f), path.join(dist, "images", f));
}

// Typsnitt: självhostade woff2 om FONT_DIR pekar på @fontsource-filer, annars Google Fonts.
let fontTags = `<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400;1,500&family=Manrope:wght@400;500;600;700&display=swap">`;
let fontCss = "";
if (process.env.FONT_DIR) {
  fs.mkdirSync(path.join(dist, "fonts"));
  for (const f of fs.readdirSync(process.env.FONT_DIR)) {
    const m = f.match(/^(cormorant-garamond|manrope)-latin-(\d+)-(normal|italic)\.woff2$/);
    if (!m) continue;
    fs.copyFileSync(path.join(process.env.FONT_DIR, f), path.join(dist, "fonts", f));
    const family = m[1] === "manrope" ? "Manrope" : "Cormorant Garamond";
    fontCss += `@font-face{font-family:"${family}";font-style:${m[3]};font-weight:${m[2]};font-display:swap;src:url(fonts/${f}) format("woff2")}`;
  }
  fontTags = `<link rel="preload" as="font" type="font/woff2" href="fonts/cormorant-garamond-latin-500-normal.woff2" crossorigin>`;
}

const html = `<!DOCTYPE html>
<html lang="sv">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>LeilasBar – Köksbar & Restaurang i Lindome</title>
<meta name="description" content="En avslappnad köksbar med vällagade klassiker, personlig service och en härlig atmosfär.">
<meta name="theme-color" content="#12110f">
${fontTags}
<link rel="preload" as="image" href="images/hero-1200.webp" imagesrcset="images/hero-640.webp 640w, images/hero-1200.webp 1200w, images/hero-1920.webp 1920w" imagesizes="100vw">
<style>:root{--font-cormorant:"Cormorant Garamond";--font-manrope:"Manrope"}${fontCss}${css}</style>
</head>
<body>
<div id="root"></div>
<script>${js.outputFiles[0].text.replace(/<\/script/g, "<\\/script")}</script>
</body>
</html>`;
fs.writeFileSync(path.join(dist, "index.html"), html);
console.log("preview built:", (html.length / 1024).toFixed(0) + " KB html");
