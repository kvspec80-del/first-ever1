import { Info, Phone } from "lucide-react";
import { menu, type Dish } from "@/data/menu";
import { telHref } from "@/config/site";
import { Picture } from "./ui/Picture";
import { Reveal } from "./ui/Reveal";
import { SectionHeading } from "./ui/SectionHeading";
import { ButtonLink } from "./ui/Button";

function Price({ value, className = "" }: { value: number; className?: string }) {
  return (
    <span className={`shrink-0 font-serif text-2xl text-gold tabular-nums lining-nums ${className}`}>
      {value}
      <span className="ml-1 font-sans text-xs tracking-[0.18em] text-stone uppercase">kr</span>
    </span>
  );
}

function FeaturedDish({ dish }: { dish: Dish }) {
  return (
    <Reveal as="article" className="group grid overflow-hidden rounded-[3px] bg-ink text-cream lg:grid-cols-2">
      <div className="relative aspect-[4/3] overflow-hidden lg:aspect-auto lg:min-h-[520px]">
        <Picture
          name={dish.image}
          alt={dish.alt}
          sizes="(min-width: 1024px) 50vw, 100vw"
          className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1.4s] ease-out group-hover:scale-105"
        />
      </div>
      <div className="flex flex-col justify-center p-8 sm:p-12 lg:p-16">
        {dish.badge && <p className="eyebrow text-gold-soft">{dish.badge}</p>}
        <h3 className="mt-5 font-serif text-4xl leading-[1.05] font-medium text-balance sm:text-5xl">{dish.name}</h3>
        <div className="my-8 h-px w-16 bg-gold/60" />
        <p className="text-lg leading-relaxed text-cream/75">{dish.description}</p>
        <div className="mt-10 flex items-center justify-between gap-6 border-t border-cream/10 pt-8">
          <span className="font-serif text-5xl text-gold-soft tabular-nums lining-nums">
            {dish.price}
            <span className="ml-2 font-sans text-sm tracking-[0.2em] text-cream/50 uppercase">kr</span>
          </span>
          <span className="text-xs tracking-[0.25em] text-cream/40 uppercase">{dish.category}</span>
        </div>
      </div>
    </Reveal>
  );
}

function DishCard({ dish, index }: { dish: Dish; index: number }) {
  return (
    <Reveal as="article" delay={(index % 3) * 90} className="group flex flex-col">
      <div className="relative aspect-[4/3] overflow-hidden rounded-[3px] bg-beige">
        <Picture
          name={dish.image}
          alt={dish.alt}
          sizes="(min-width: 1024px) 31vw, (min-width: 640px) 46vw, 100vw"
          className="h-full w-full object-cover transition-transform duration-[1.2s] ease-out group-hover:scale-[1.06]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink/30 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
        {dish.badge && (
          <span className="absolute top-4 left-4 rounded-full bg-cream/95 px-3.5 py-1.5 text-[0.65rem] font-semibold tracking-[0.2em] text-ink uppercase backdrop-blur">
            {dish.badge}
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col pt-6">
        <p className="text-[0.68rem] font-medium tracking-[0.28em] text-gold uppercase">{dish.category}</p>
        <div className="mt-2 flex items-baseline gap-3">
          <h3 className="font-serif text-[1.65rem] leading-tight font-medium text-ink">{dish.name}</h3>
          <span aria-hidden="true" className="menu-leader mb-1.5 flex-1" />
          <Price value={dish.price} />
        </div>
        <p className="mt-3 leading-relaxed text-stone">{dish.description}</p>
      </div>
    </Reveal>
  );
}

export function MenuSection() {
  const [featured, ...rest] = menu;
  return (
    <section id="meny" aria-labelledby="meny-title" className="relative bg-sand-50 py-24 sm:py-32 lg:py-40">
      <div className="container-x">
        <SectionHeading
          id="meny-title"
          eyebrow="Kvällsmeny"
          title="Vår kvällsmeny"
          subtitle="Vällagade favoriter med omsorg om varje detalj."
        />

        <div className="mt-16 sm:mt-20">
          <FeaturedDish dish={featured} />
        </div>

        <div className="mt-16 grid gap-x-8 gap-y-16 sm:grid-cols-2 lg:mt-20 lg:grid-cols-3 lg:gap-x-10">
          {rest.map((dish, i) => (
            <DishCard key={dish.name} dish={dish} index={i} />
          ))}
        </div>

        <Reveal className="mt-20 flex flex-col items-center justify-between gap-6 rounded-[3px] border border-ink/10 bg-cream px-6 py-7 text-center sm:flex-row sm:px-10 sm:text-left">
          <p className="flex items-start gap-3 text-stone sm:items-center">
            <Info className="mt-0.5 h-5 w-5 shrink-0 text-gold sm:mt-0" aria-hidden="true" />
            <span>
              <strong className="font-semibold text-ink">Menyn kan variera</strong> efter säsong och tillgång. Fråga
              gärna personalen om allergener och specialkost.
            </span>
          </p>
          <ButtonLink href={telHref} variant="dark" icon={<Phone className="h-4 w-4" aria-hidden="true" />} className="shrink-0">
            Boka bord
          </ButtonLink>
        </Reveal>
      </div>
    </section>
  );
}
