import { Navbar } from "./Navbar";
import { Hero } from "./Hero";
import { Intro } from "./Intro";
import { MenuSection } from "./MenuSection";
import { Events } from "./Events";
import { Gallery } from "./Gallery";
import { About } from "./About";
import { Booking } from "./Booking";
import { Contact } from "./Contact";
import { Footer } from "./Footer";
import { MobileBookBar } from "./MobileBookBar";

export function HomePage() {
  return (
    <>
      <Navbar />
      <main id="main">
        <Hero />
        <Intro />
        <MenuSection />
        <Events />
        <Gallery />
        <About />
        <Booking />
        <Contact />
      </main>
      <Footer />
      <MobileBookBar />
    </>
  );
}
