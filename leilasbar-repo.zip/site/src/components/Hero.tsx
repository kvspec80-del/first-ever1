import { Phone, UtensilsCrossed } from "lucide-react";
import { site, telHref } from "@/config/site";
import { Picture } from "./ui/Picture";
import { ButtonLink } from "./ui/Button";

export function Hero() {
  return (
    <section id="hem" aria-labelledby="hero-title" className="relative flex min-h-[100svh] items-end overflow-hidden bg-ink">
      <div className="absolute inset-0">
        <Picture
          name="hero"
          alt="Stämningsfull köksbar med varmt ljus från glödlampor över bardisken"
          sizes="100vw"
          priority
          className="hero-img h-full w-full object-cover object-[50%_42%]"
        />
        {/* Diskret mörk toning för läsbarhet */}
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/55 to-ink/35" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_30%_80%,rgba(15,14,12,0.65),transparent_60%)]" />
      </div>

      <div className="container-x relative z-10 pt-40 pb-28 sm:pb-32 lg:pb-36">
        <div className="max-w-3xl">
          <p className="eyebrow hero-in text-gold-soft" style={{ animationDelay: "100ms" }}>
            {site.tagline} · {site.city}
          </p>
          <h1 id="hero-title" className="mt-6 font-serif font-medium tracking-tight text-cream">
            <span className="hero-in block text-[2.6rem] leading-[1] sm:text-6xl lg:text-7xl" style={{ animationDelay: "200ms" }}>
              Välkommen till
            </span>
            <span
              className="hero-in mt-2 block text-[2.4rem] leading-[1.05] text-gold-soft italic sm:text-6xl lg:text-[4.6rem]"
              style={{ animationDelay: "320ms" }}
            >
              {site.name}
            </span>
          </h1>
          <p className="hero-in mt-7 max-w-xl text-lg leading-relaxed text-cream/80 sm:text-xl" style={{ animationDelay: "450ms" }}>
            God mat, härlig atmosfär och minnesvärda kvällar.
          </p>
          <div className="hero-in mt-10 flex flex-col gap-3 sm:flex-row sm:gap-4" style={{ animationDelay: "580ms" }}>
            <ButtonLink href="#meny" size="lg" variant="gold" icon={<UtensilsCrossed className="h-4 w-4" aria-hidden="true" />}>
              Se vår meny
            </ButtonLink>
            <ButtonLink href={telHref} size="lg" variant="outline-light" icon={<Phone className="h-4 w-4" aria-hidden="true" />}>
              Boka bord
            </ButtonLink>
          </div>
        </div>
      </div>

      <a
        href="#valkommen"
        className="group absolute bottom-7 left-1/2 z-10 hidden -translate-x-1/2 flex-col items-center gap-3 text-[0.65rem] font-medium tracking-[0.35em] text-cream/60 uppercase transition-colors hover:text-cream sm:flex"
        aria-label="Scrolla ned till nästa sektion"
      >
        Upptäck
        <span className="relative flex h-11 w-6 justify-center rounded-full border border-cream/35">
          <span className="scroll-dot mt-2 h-2 w-[3px] rounded-full bg-gold-soft" />
        </span>
      </a>
    </section>
  );
}
