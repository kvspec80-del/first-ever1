"use client";

import { useEffect, useState } from "react";
import { Phone, UtensilsCrossed } from "lucide-react";
import { telHref } from "@/config/site";

/** Fast bokningsknapp i nederkant på mobil – visas efter hero, döljs vid bokningssektionen. */
export function MobileBookBar() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const booking = document.getElementById("boka");
    let nearBooking = false;
    const io = booking
      ? new IntersectionObserver(([e]) => {
          nearBooking = e.isIntersecting;
          update();
        })
      : null;
    function update() {
      setShow(window.scrollY > window.innerHeight * 0.75 && !nearBooking);
    }
    if (booking && io) io.observe(booking);
    update();
    window.addEventListener("scroll", update, { passive: true });
    return () => {
      window.removeEventListener("scroll", update);
      io?.disconnect();
    };
  }, []);

  return (
    <div
      className={`fixed inset-x-0 bottom-0 z-40 px-4 pb-[max(1rem,env(safe-area-inset-bottom))] transition-all duration-500 sm:hidden ${
        show ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-full opacity-0"
      }`}
      aria-hidden={!show}
    >
      <div className="flex gap-2 rounded-full border border-cream/10 bg-ink/90 p-1.5 shadow-2xl backdrop-blur-xl">
        <a href="#meny" tabIndex={show ? 0 : -1} className="flex h-12 flex-1 items-center justify-center gap-2 rounded-full text-sm font-medium text-cream">
          <UtensilsCrossed className="h-4 w-4" aria-hidden="true" /> Meny
        </a>
        <a href={telHref} tabIndex={show ? 0 : -1} className="flex h-12 flex-[1.4] items-center justify-center gap-2 rounded-full bg-gold text-sm font-semibold text-ink">
          <Phone className="h-4 w-4" aria-hidden="true" /> Boka bord
        </a>
      </div>
    </div>
  );
}
