import { Facebook, Instagram, Phone } from "lucide-react";
import { fullAddress, mapsSearchUrl, navItems, site, telHref } from "@/config/site";
import { Logo } from "./Logo";

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="bg-ink text-cream/70" aria-labelledby="footer-title">
      <h2 id="footer-title" className="sr-only">Sidfot</h2>
      <div className="container-x grid gap-12 py-20 sm:grid-cols-2 lg:grid-cols-12 lg:gap-10">
        <div className="sm:col-span-2 lg:col-span-4">
          <Logo />
          <p className="mt-6 max-w-sm leading-relaxed">{site.description}</p>
          <div className="mt-8 flex gap-3">
            <a href={site.social.instagram} target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="social-btn">
              <Instagram className="h-[18px] w-[18px]" />
            </a>
            <a href={site.social.facebook} target="_blank" rel="noopener noreferrer" aria-label="Facebook" className="social-btn">
              <Facebook className="h-[18px] w-[18px]" />
            </a>
          </div>
        </div>

        <div className="lg:col-span-2">
          <h3 className="footer-h">Utforska</h3>
          <ul className="mt-5 space-y-3">
            {navItems.map((n) => (
              <li key={n.href}>
                <a href={n.href} className="transition-colors hover:text-gold-soft">{n.label}</a>
              </li>
            ))}
            <li>
              <a href="#handelser" className="transition-colors hover:text-gold-soft">Det händer</a>
            </li>
          </ul>
        </div>

        <div className="lg:col-span-3">
          <h3 className="footer-h">Kontakt</h3>
          <ul className="mt-5 space-y-3">
            <li>
              <a href={mapsSearchUrl} target="_blank" rel="noopener noreferrer" className="transition-colors hover:text-gold-soft">{fullAddress}</a>
            </li>
            <li>
              <a href={telHref} className="transition-colors hover:text-gold-soft">{site.phone.display}</a>
            </li>
            <li>
              <a href={`mailto:${site.email}`} className="transition-colors hover:text-gold-soft">{site.email}</a>
            </li>
          </ul>
        </div>

        <div className="lg:col-span-3">
          <h3 className="footer-h">Öppettider</h3>
          <ul className="mt-5 space-y-3">
            {site.hours.map((h) => (
              <li key={h.days} className="flex flex-col">
                <span className="text-cream/45 text-sm">{h.days}</span>
                <span className="text-cream">{h.time}</span>
              </li>
            ))}
          </ul>
          <a href={telHref} className="mt-7 inline-flex items-center gap-2 text-sm font-semibold text-gold-soft hover:text-cream">
            <Phone className="h-4 w-4" aria-hidden="true" /> Boka bord
          </a>
        </div>
      </div>

      <div className="border-t border-cream/10">
        <div className="container-x flex flex-col items-center justify-between gap-3 py-7 text-sm text-cream/40 sm:flex-row">
          <p>© {year} {site.name}. Alla rättigheter förbehållna.</p>
          <a href="#hem" className="transition-colors hover:text-cream">Till toppen ↑</a>
        </div>
      </div>
    </footer>
  );
}
