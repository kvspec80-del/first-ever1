import { Navigation, MapPin } from "lucide-react";
import { fullAddress, mapsSearchUrl, site } from "@/config/site";
import { Reveal } from "./ui/Reveal";

/**
 * Kartsektion. Om `site.mapEmbedUrl` är ifylld visas en riktig Google Maps-karta,
 * annars en stilren platshållare med länk till vägbeskrivning.
 */
export function Contact() {
  return (
    <section id="kontakt" aria-labelledby="kontakt-title" className="bg-sand-50 py-24 sm:py-28">
      <div className="container-x grid items-stretch gap-10 lg:grid-cols-[1fr_1.6fr] lg:gap-16">
        <Reveal className="flex flex-col justify-center">
          <p className="eyebrow text-gold">Hitta hit</p>
          <h2 id="kontakt-title" className="mt-5 font-serif text-4xl leading-[1.05] font-medium tracking-tight text-ink sm:text-5xl">
            Varmt välkommen förbi
          </h2>
          <address className="mt-7 text-lg leading-relaxed text-stone not-italic">
            {site.name}
            <br />
            {site.address.street}
            <br />
            {site.address.postalCode} {site.address.city}
          </address>
          <a
            href={mapsSearchUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-8 inline-flex items-center gap-2 self-start border-b border-ink/30 pb-1 font-medium text-ink transition-colors hover:border-gold hover:text-gold"
          >
            <Navigation className="h-4 w-4" aria-hidden="true" />
            Vägbeskrivning i Google Maps
          </a>
        </Reveal>

        <Reveal delay={100}>
          <div className="relative h-[340px] overflow-hidden rounded-[3px] border border-ink/10 bg-beige sm:h-[440px]">
            {site.mapEmbedUrl ? (
              <iframe
                src={site.mapEmbedUrl}
                title={`Karta som visar ${site.name}`}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="h-full w-full grayscale-[0.4] sepia-[0.15]"
              />
            ) : (
              <div className="map-placeholder flex h-full w-full flex-col items-center justify-center p-8 text-center">
                <span className="relative flex h-16 w-16 items-center justify-center">
                  <span className="map-ping absolute inset-0 rounded-full bg-gold/30" />
                  <span className="relative flex h-14 w-14 items-center justify-center rounded-full bg-ink text-gold-soft shadow-xl">
                    <MapPin className="h-6 w-6" aria-hidden="true" />
                  </span>
                </span>
                <p className="mt-6 font-serif text-2xl text-ink">{fullAddress}</p>
                <p className="mt-2 max-w-sm text-sm text-stone">
                  [KARTA] – lägg in er Google Maps-inbäddning i <code className="rounded bg-cream px-1.5 py-0.5 text-xs">src/config/site.ts</code>
                </p>
              </div>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
