import { ArrowUpRight, CalendarDays } from "lucide-react";
import { events, type RestaurantEvent } from "@/data/events";
import { telHref } from "@/config/site";
import { Picture } from "./ui/Picture";
import { Reveal } from "./ui/Reveal";
import { SectionHeading } from "./ui/SectionHeading";

function EventCard({ event, large, index }: { event: RestaurantEvent; large?: boolean; index: number }) {
  const cta = event.cta ?? { label: "Ring och boka", href: telHref };
  return (
    <Reveal
      as="article"
      delay={index * 90}
      className={`group relative isolate flex w-full overflow-hidden rounded-[3px] bg-charcoal ${
        large ? "min-h-[520px]" : "min-h-[340px]"
      }`}
    >
      <Picture
        name={event.image}
        alt={event.alt}
        sizes={large ? "(min-width: 1024px) 50vw, 100vw" : "(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw"}
        className="absolute inset-0 -z-10 h-full w-full object-cover opacity-80 transition-all duration-[1.3s] ease-out group-hover:scale-105 group-hover:opacity-60"
      />
      <div className="absolute inset-0 -z-10 bg-gradient-to-t from-ink via-ink/60 to-ink/5" />
      <div className="mt-auto flex w-full flex-col p-7 sm:p-9">
        <div className="flex flex-wrap items-center gap-3">
          <span className="rounded-full border border-gold-soft/50 px-3 py-1 text-[0.65rem] font-semibold tracking-[0.22em] text-gold-soft uppercase">
            {event.tag}
          </span>
          <span className="inline-flex items-center gap-1.5 text-sm text-cream/70">
            <CalendarDays className="h-4 w-4" aria-hidden="true" />
            {event.when}
          </span>
        </div>
        <h3 className={`mt-5 font-serif leading-[1.05] font-medium text-cream ${large ? "text-4xl sm:text-5xl" : "text-3xl"}`}>
          {event.title}
        </h3>
        <p className={`mt-4 leading-relaxed text-cream/75 ${large ? "max-w-md text-lg" : "line-clamp-3"}`}>{event.description}</p>
        <a
          href={cta.href}
          className="mt-7 inline-flex items-center gap-2 self-start border-b border-gold-soft/50 pb-1 text-sm font-medium tracking-wide text-gold-soft transition-colors hover:border-gold-soft hover:text-cream"
        >
          {cta.label}
          <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" aria-hidden="true" />
        </a>
      </div>
    </Reveal>
  );
}

export function Events() {
  const list = events.filter((e) => e.visible !== false);
  if (list.length === 0) return null;
  const [first, ...rest] = list;
  return (
    <section id="handelser" aria-labelledby="events-title" className="bg-ink py-24 sm:py-32 lg:py-40">
      <div className="container-x">
        <div className="flex flex-col justify-between gap-8 lg:flex-row lg:items-end">
          <SectionHeading
            id="events-title"
            tone="dark"
            align="left"
            eyebrow="Aktuellt"
            title="Det händer hos oss"
            subtitle="Temakvällar, säsongsmenyer och högtider – här hittar du det senaste från köksbaren."
          />
        </div>
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:mt-20 lg:grid-cols-4 lg:grid-rows-2 lg:gap-6">
          <div className="flex sm:col-span-2 lg:row-span-2">
            <EventCard event={first} large index={0} />
          </div>
          {rest.map((e, i) => (
            <div key={e.title} className={`flex ${i === rest.length - 1 && rest.length === 3 ? "sm:col-span-2" : ""}`}>
              <EventCard event={e} index={i + 1} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
