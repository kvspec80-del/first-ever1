"use client";

import { useEffect, useRef, useState } from "react";
import { Menu, Phone, X } from "lucide-react";
import { navItems, site, telHref } from "@/config/site";
import { Logo } from "./Logo";

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("#hem");
  const toggleRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  // Transparent över hero → solid vid scroll
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Markera aktiv sektion
  useEffect(() => {
    const sections = navItems
      .map((n) => document.querySelector<HTMLElement>(n.href))
      .filter((el): el is HTMLElement => Boolean(el));
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(`#${e.target.id}`);
        });
      },
      { rootMargin: "-45% 0px -50% 0px" },
    );
    sections.forEach((s) => io.observe(s));
    return () => io.disconnect();
  }, []);

  // Mobilmeny: lås scroll, Esc stänger, fokus in i panelen
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    panelRef.current?.querySelector<HTMLElement>("a")?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        toggleRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const solid = scrolled || open;

  return (
    <>
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        solid
          ? "border-b border-cream/10 bg-ink/90 py-3 shadow-[0_10px_40px_-20px_rgba(0,0,0,0.6)] backdrop-blur-xl"
          : "border-b border-transparent bg-transparent py-5 sm:py-6"
      }`}
    >
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:rounded-full focus:bg-gold focus:px-4 focus:py-2 focus:text-ink">
        Hoppa till innehållet
      </a>
      <nav aria-label="Huvudmeny" className="container-x flex items-center justify-between gap-6">
        <Logo />

        <ul className="hidden items-center gap-1 lg:flex">
          {navItems.map((item) => (
            <li key={item.href}>
              <a
                href={item.href}
                aria-current={active === item.href ? "true" : undefined}
                className={`nav-link relative px-4 py-2 text-[0.82rem] font-medium tracking-[0.14em] uppercase transition-colors ${
                  active === item.href ? "text-cream" : "text-cream/70 hover:text-cream"
                }`}
              >
                {item.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <a
            href={telHref}
            className="hidden h-11 items-center gap-2 rounded-full bg-gold px-6 text-sm font-semibold tracking-wide text-ink transition-all duration-300 hover:bg-gold-soft hover:shadow-[0_8px_30px_-10px_rgba(212,180,124,0.8)] sm:inline-flex"
          >
            <Phone className="h-4 w-4" aria-hidden="true" />
            Boka bord
          </a>
          <button
            ref={toggleRef}
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="mobilmeny"
            aria-label={open ? "Stäng meny" : "Öppna meny"}
            className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-cream/25 text-cream transition-colors hover:border-cream/60 lg:hidden"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </nav>
    </header>

      {/* Mobilmeny – utanför <header> så att backdrop-filter inte begränsar position: fixed */}
      <div
        id="mobilmeny"
        ref={panelRef}
        hidden={!open}
        className="fixed inset-x-0 top-[68px] bottom-0 z-40 overflow-y-auto bg-ink lg:hidden"
      >
        <div className="container-x flex min-h-full flex-col pt-8 pb-10">
          <ul className="flex flex-col">
            {navItems.map((item, i) => (
              <li key={item.href} className="mobile-item border-b border-cream/10" style={{ animationDelay: `${60 + i * 50}ms` }}>
                <a
                  href={item.href}
                  onClick={() => setOpen(false)}
                  className="flex items-baseline justify-between py-5 font-serif text-4xl text-cream transition-colors hover:text-gold-soft"
                >
                  {item.label}
                  <span className="font-sans text-xs tracking-[0.3em] text-cream/30">0{i + 1}</span>
                </a>
              </li>
            ))}
          </ul>
          <div className="mobile-item mt-auto pt-10" style={{ animationDelay: "340ms" }}>
            <a
              href={telHref}
              onClick={() => setOpen(false)}
              className="flex h-14 w-full items-center justify-center gap-3 rounded-full bg-gold text-base font-semibold text-ink"
            >
              <Phone className="h-5 w-5" aria-hidden="true" />
              Ring och boka bord
            </a>
            <p className="mt-4 text-center text-sm text-cream/50">{site.phone.display}</p>
          </div>
        </div>
      </div>
    </>
  );
}
