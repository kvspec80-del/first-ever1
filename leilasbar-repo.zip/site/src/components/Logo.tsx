import { site } from "@/config/site";

/** Logotyp: en enkel emblem-symbol + restaurangens namn. Byt gärna mot er egen SVG. */
export function Logo({ tone = "light", className = "" }: { tone?: "light" | "dark"; className?: string }) {
  const text = tone === "light" ? "text-cream" : "text-ink";
  return (
    <a href="#hem" className={`group inline-flex items-center gap-3 ${className}`} aria-label={`${site.name} – till startsidan`}>
      <svg viewBox="0 0 40 40" className="h-9 w-9 shrink-0 text-gold transition-transform duration-500 group-hover:rotate-[20deg]" aria-hidden="true">
        <circle cx="20" cy="20" r="18.5" fill="none" stroke="currentColor" strokeWidth="1" />
        <circle cx="20" cy="20" r="14.5" fill="none" stroke="currentColor" strokeWidth="0.5" opacity="0.6" />
        {/* Stiliserad stjärna/ljuslåga – nordisk enkelhet */}
        <path d="M20 9.5 L22 18 L30.5 20 L22 22 L20 30.5 L18 22 L9.5 20 L18 18 Z" fill="currentColor" />
      </svg>
      <span className="flex flex-col leading-none">
        <span className={`font-serif text-[1.05rem] font-semibold tracking-wide sm:text-xl ${text}`}>{site.name}</span>
        <span className="mt-1 text-[0.6rem] font-medium tracking-[0.32em] text-gold uppercase">{site.tagline}</span>
      </span>
    </a>
  );
}
