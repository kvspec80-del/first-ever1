import { imageFallback, imageSrcSet, type ImageName } from "@/lib/images";
import { imageMeta } from "@/lib/image-meta";

type Props = {
  name: ImageName;
  alt: string;
  /** Responsiv sizes-sträng, t.ex. "(min-width: 1024px) 33vw, 100vw". */
  sizes: string;
  className?: string;
  /** true för bilder ovanför vecket (hero) – laddas direkt med hög prioritet. */
  priority?: boolean;
};

/**
 * Föroptimerade WebP-bilder i flera bredder med srcset, lazy loading och fasta
 * dimensioner (ingen layoutförskjutning). Fungerar både med `next build` och statisk export.
 */
export function Picture({ name, alt, sizes, className, priority }: Props) {
  const meta = imageMeta[name];
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={imageFallback(name)}
      srcSet={imageSrcSet(name)}
      sizes={sizes}
      width={meta.width}
      height={meta.height}
      alt={alt}
      loading={priority ? "eager" : "lazy"}
      decoding={priority ? "sync" : "async"}
      fetchPriority={priority ? "high" : "auto"}
      className={className}
    />
  );
}
