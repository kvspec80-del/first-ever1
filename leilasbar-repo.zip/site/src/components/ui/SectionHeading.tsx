import { Reveal } from "./Reveal";

type Props = {
  eyebrow: string;
  title: string;
  subtitle?: string;
  align?: "center" | "left";
  tone?: "light" | "dark";
  id?: string;
};

export function SectionHeading({ eyebrow, title, subtitle, align = "center", tone = "light", id }: Props) {
  const center = align === "center";
  const dark = tone === "dark";
  return (
    <Reveal className={`${center ? "mx-auto text-center" : ""} max-w-2xl`}>
      <p className={`eyebrow ${center ? "justify-center" : ""} ${dark ? "text-gold-soft" : "text-gold"}`}>
        {eyebrow}
      </p>
      <h2
        id={id}
        className={`mt-5 font-serif text-4xl leading-[1.05] font-medium tracking-tight text-balance sm:text-5xl lg:text-[3.5rem] ${
          dark ? "text-cream" : "text-ink"
        }`}
      >
        {title}
      </h2>
      {subtitle && (
        <p className={`mt-5 text-lg leading-relaxed text-pretty ${dark ? "text-cream/70" : "text-stone"}`}>
          {subtitle}
        </p>
      )}
    </Reveal>
  );
}
