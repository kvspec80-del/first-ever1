import type { AnchorHTMLAttributes, ReactNode } from "react";

type Variant = "gold" | "outline-light" | "outline-dark" | "dark";

const variants: Record<Variant, string> = {
  gold: "bg-gold text-ink hover:bg-gold-soft shadow-[0_10px_30px_-12px_rgba(184,149,90,0.7)]",
  dark: "bg-ink text-cream hover:bg-charcoal",
  "outline-light": "border border-cream/40 text-cream hover:border-cream hover:bg-cream/10",
  "outline-dark": "border border-ink/25 text-ink hover:border-ink hover:bg-ink hover:text-cream",
};

type Props = AnchorHTMLAttributes<HTMLAnchorElement> & {
  variant?: Variant;
  size?: "md" | "lg";
  icon?: ReactNode;
};

export function ButtonLink({ variant = "gold", size = "md", icon, className = "", children, ...rest }: Props) {
  const sizing = size === "lg" ? "h-14 px-8 text-[0.95rem]" : "h-12 px-6 text-sm";
  return (
    <a
      className={`group inline-flex items-center justify-center gap-2.5 rounded-full font-medium tracking-wide transition-all duration-300 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-gold active:scale-[0.98] ${sizing} ${variants[variant]} ${className}`}
      {...rest}
    >
      {icon}
      <span>{children}</span>
    </a>
  );
}
