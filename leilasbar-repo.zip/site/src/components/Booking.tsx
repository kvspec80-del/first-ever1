import { Clock, MapPin, Phone } from "lucide-react";
import { fullAddress, mapsSearchUrl, site, telHref } from "@/config/site";
import { Picture } from "./ui/Picture";
import { Reveal } from "./ui/Reveal";

export function Booking() {
  return (
    <section id="boka" aria-labelledby="boka-title" className="relative isolate overflow-hidden bg-ink py-24 sm:py-32 lg:py-40">
      <Picture
        name="booking"
        alt=""
        sizes="100vw"
        className="absolute inset-0 -z-20 h-full w-full object-cover opacity-45"
      />
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-ink/80 via-ink/70 to-ink/95" />

      <div className="container-x">
        <div className="mx-auto grid max-w-6xl items-center gap-12 lg:grid-cols-[1.1fr_1fr] lg:gap-20">
          <Reveal className="text-center lg:text-left">
            <p className="eyebrow justify-center text-gold-soft lg:justify-start">Bordsbokning</p>
            <h2 id="boka-title" className="mt-5 font-serif text-5xl leading-[1] font-medium tracking-tight text-cream sm:text-6xl lg:text-7xl">
              Boka ditt bord
            </h2>
            <p className="mx-auto mt-6 max-w-md text-lg leading-relaxed text-cream/75 lg:mx-0">
              Planerar du en trevlig middag? Vi ser fram emot att välkomna dig!
            </p>
            <div className="mt-10 flex flex-col items-center gap-4 lg:items-start">
              <a
                href={telHref}
                className="group inline-flex h-16 items-center gap-4 rounded-full bg-gold pr-9 pl-3 text-lg font-semibold text-ink shadow-[0_20px_50px_-15px_rgba(184,149,90,0.75)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-gold-soft focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-gold-soft sm:h-[4.5rem] sm:text-xl"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-ink text-gold-soft transition-transform duration-500 group-hover:rotate-[-12deg] sm:h-12 sm:w-12">
                  <Phone className="h-5 w-5" aria-hidden="true" />
                </span>
                Ring och boka bord
              </a>
              <a href={telHref} className="font-serif text-2xl tracking-wide text-cream/90 tabular-nums lining-nums hover:text-gold-soft">
                {site.phone.display}
              </a>
            </div>
          </Reveal>

          <Reveal delay={120}>
            <div className="rounded-[3px] border border-cream/15 bg-ink/60 p-8 backdrop-blur-md sm:p-10">
              <dl className="space-y-8">
                <div className="flex gap-5">
                  <dt className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-gold/40 text-gold-soft">
                    <Phone className="h-[18px] w-[18px]" aria-hidden="true" />
                    <span className="sr-only">Telefon</span>
                  </dt>
                  <dd>
                    <p className="text-xs tracking-[0.25em] text-cream/50 uppercase">Telefon</p>
                    <a href={telHref} className="mt-1.5 block text-lg text-cream hover:text-gold-soft">{site.phone.display}</a>
                  </dd>
                </div>
                <div className="flex gap-5">
                  <dt className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-gold/40 text-gold-soft">
                    <MapPin className="h-[18px] w-[18px]" aria-hidden="true" />
                    <span className="sr-only">Adress</span>
                  </dt>
                  <dd>
                    <p className="text-xs tracking-[0.25em] text-cream/50 uppercase">Adress</p>
                    <a href={mapsSearchUrl} target="_blank" rel="noopener noreferrer" className="mt-1.5 block text-lg text-cream hover:text-gold-soft">
                      {fullAddress}
                    </a>
                  </dd>
                </div>
                <div className="flex gap-5">
                  <dt className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-gold/40 text-gold-soft">
                    <Clock className="h-[18px] w-[18px]" aria-hidden="true" />
                    <span className="sr-only">Öppettider</span>
                  </dt>
                  <dd className="flex-1">
                    <p className="text-xs tracking-[0.25em] text-cream/50 uppercase">Öppettider</p>
                    <ul className="mt-2 space-y-2">
                      {site.hours.map((h) => (
                        <li key={h.days} className="flex flex-wrap justify-between gap-x-6 gap-y-0.5 text-cream">
                          <span className="text-cream/70">{h.days}</span>
                          <span className="tabular-nums">{h.time}</span>
                        </li>
                      ))}
                    </ul>
                  </dd>
                </div>
              </dl>
              <p className="mt-8 border-t border-cream/10 pt-6 text-sm leading-relaxed text-cream/55">
                Större sällskap eller särskilda önskemål? Ring oss så hjälper vi dig gärna.
              </p>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
