import { HeartHandshake, ChefHat, Wine } from "lucide-react";
import { site } from "@/config/site";
import { Picture } from "./ui/Picture";
import { Reveal } from "./ui/Reveal";

const pillars = [
  { icon: ChefHat, title: "Vällagade klassiker", text: "Lagat från grunden i vårt kök." },
  { icon: HeartHandshake, title: "Personlig service", text: "Varmt bemötande, varje kväll." },
  { icon: Wine, title: "Härlig atmosfär", text: "Middag, drinkar och gott sällskap." },
];

export function Intro() {
  return (
    <section id="valkommen" aria-labelledby="intro-title" className="relative overflow-hidden bg-cream py-24 sm:py-32 lg:py-40">
      <div className="container-x grid items-center gap-14 lg:grid-cols-12 lg:gap-20">
        <Reveal className="relative lg:col-span-6">
          <div className="relative aspect-[4/5] overflow-hidden rounded-[2px] sm:aspect-[5/4] lg:aspect-[4/5]">
            <Picture
              name="intro"
              alt="Dukat bord med vinglas och en vackert upplagd varmrätt"
              sizes="(min-width: 1024px) 45vw, 100vw"
              className="h-full w-full object-cover transition-transform duration-[1.6s] ease-out hover:scale-[1.03]"
            />
          </div>
          {/* Guldram förskjuten bakom bilden */}
          <div aria-hidden="true" className="absolute -right-4 -bottom-4 -z-0 hidden h-full w-full border border-gold/50 sm:block lg:-right-6 lg:-bottom-6" style={{ zIndex: -1 }} />
          <div className="absolute -bottom-8 left-6 hidden rounded-[2px] bg-ink px-7 py-6 text-cream shadow-2xl sm:block lg:-left-10">
            <p className="font-serif text-4xl text-gold-soft italic">Sedan [ÅR]</p>
            <p className="mt-1 text-xs tracking-[0.28em] text-cream/60 uppercase">Köksbar i {site.city}</p>
          </div>
        </Reveal>

        <div className="lg:col-span-6">
          <Reveal>
            <p className="eyebrow text-gold">Välkommen</p>
            <h2 id="intro-title" className="mt-5 font-serif text-4xl leading-[1.05] font-medium tracking-tight text-balance text-ink sm:text-5xl lg:text-[3.4rem]">
              En plats för god mat och trevliga stunder.
            </h2>
            <p className="mt-7 text-lg leading-relaxed text-pretty text-stone">
              Välkommen till vår köksbar – en avslappnad mötesplats där god mat, personlig service och en härlig
              atmosfär står i centrum. Hos oss kan du njuta av vällagade klassiker, goda smaker och trevliga kvällar
              i gott sällskap.
            </p>
          </Reveal>

          <ul className="mt-12 grid gap-px overflow-hidden border-y border-ink/10 sm:grid-cols-3">
            {pillars.map((p, i) => (
              <Reveal as="li" key={p.title} delay={i * 90} className="py-6 sm:px-5 sm:first:pl-0">
                <p.icon className="h-6 w-6 text-gold" strokeWidth={1.4} aria-hidden="true" />
                <p className="mt-4 font-serif text-xl text-ink">{p.title}</p>
                <p className="mt-1.5 text-sm leading-relaxed text-stone">{p.text}</p>
              </Reveal>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
