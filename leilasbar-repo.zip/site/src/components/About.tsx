import { Picture } from "./ui/Picture";
import { Reveal } from "./ui/Reveal";

const values = [
  { n: "01", title: "Kvalitet", text: "Noga utvalda råvaror och rätter lagade med hantverk." },
  { n: "02", title: "Omtanke", text: "Vi tar hand om varje gäst – från första hej till sista kaffet." },
  { n: "03", title: "Gemenskap", text: "En plats att samlas, umgås och stanna kvar lite längre." },
];

export function About() {
  return (
    <section id="om-oss" aria-labelledby="om-title" className="relative overflow-hidden bg-charcoal text-cream">
      <div className="grid lg:grid-cols-2">
        <div className="relative min-h-[420px] sm:min-h-[560px] lg:min-h-[760px]">
          <Picture
            name="about"
            alt="Gäster som njuter av middag och samtal vid ett långbord"
            sizes="(min-width: 1024px) 50vw, 100vw"
            className="absolute inset-0 h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-charcoal/80 via-transparent to-transparent lg:bg-gradient-to-r lg:from-transparent lg:via-transparent lg:to-charcoal/70" />
        </div>

        <div className="flex items-center px-5 py-20 sm:px-10 sm:py-24 lg:px-16 lg:py-32 xl:px-24">
          <div className="max-w-xl">
            <Reveal>
              <p className="eyebrow text-gold-soft">Om oss</p>
              <h2 id="om-title" className="mt-5 font-serif text-4xl leading-[1.05] font-medium tracking-tight text-balance sm:text-5xl lg:text-[3.5rem]">
                Mer än bara en middag
              </h2>
              <p className="mt-7 text-lg leading-relaxed text-pretty text-cream/75">
                Vi vill skapa en plats där människor samlas, umgås och njuter av god mat. Med fokus på kvalitet,
                omtanke och en personlig atmosfär strävar vi efter att varje besök ska bli något extra.
              </p>
            </Reveal>

            <dl className="mt-12 space-y-0 border-t border-cream/10">
              {values.map((v, i) => (
                <Reveal key={v.n} delay={i * 90} className="grid grid-cols-[3rem_1fr] gap-4 border-b border-cream/10 py-6">
                  <dt className="font-serif text-lg text-gold-soft italic">{v.n}</dt>
                  <dd>
                    <p className="font-serif text-2xl">{v.title}</p>
                    <p className="mt-1 text-cream/60">{v.text}</p>
                  </dd>
                </Reveal>
              ))}
            </dl>
          </div>
        </div>
      </div>
    </section>
  );
}
