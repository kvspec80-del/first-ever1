"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Expand, X } from "lucide-react";
import { gallery } from "@/data/gallery";
import { imageSrc } from "@/lib/images";
import { Picture } from "./ui/Picture";
import { Reveal } from "./ui/Reveal";
import { SectionHeading } from "./ui/SectionHeading";

const spanClass = {
  big: "col-span-2 row-span-2",
  wide: "col-span-2",
  tall: "row-span-2",
} as const;

export function Gallery() {
  const [index, setIndex] = useState<number | null>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const lastTrigger = useRef<HTMLElement | null>(null);

  const close = useCallback(() => {
    setIndex(null);
    lastTrigger.current?.focus();
  }, []);
  const step = useCallback((d: number) => setIndex((i) => (i === null ? i : (i + d + gallery.length) % gallery.length)), []);

  useEffect(() => {
    if (index === null) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowRight") step(1);
      if (e.key === "ArrowLeft") step(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [index, close, step]);

  const current = index === null ? null : gallery[index];

  return (
    <section id="galleri" aria-labelledby="galleri-title" className="bg-cream py-24 sm:py-32 lg:py-40">
      <div className="container-x">
        <SectionHeading
          id="galleri-title"
          eyebrow="Galleri"
          title="Smaker, miljö & upplevelser"
          subtitle="En glimt av kvällarna hos oss – från köket och baren till dukade bord."
        />

        <ul className="mt-16 grid grid-flow-dense auto-rows-[170px] grid-cols-2 gap-3 sm:mt-20 sm:auto-rows-[220px] sm:gap-4 lg:auto-rows-[250px] lg:grid-cols-4 lg:gap-5">
          {gallery.map((item, i) => {
            const span = item.span ? spanClass[item.span] : "";
            return (
              <Reveal as="li" key={item.image} delay={(i % 4) * 70} className={span}>
                <button
                  type="button"
                  onClick={(e) => {
                    lastTrigger.current = e.currentTarget;
                    setIndex(i);
                  }}
                  className="group relative block h-full w-full overflow-hidden rounded-[3px] bg-beige focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-gold"
                  aria-label={`Visa större bild: ${item.caption}`}
                >
                  <Picture
                    name={item.image}
                    alt={item.alt}
                    sizes={item.span === "big" || item.span === "wide" ? "(min-width: 1024px) 50vw, 100vw" : "(min-width: 1024px) 25vw, 50vw"}
                    className="h-full w-full object-cover transition-transform duration-[1.2s] ease-out group-hover:scale-[1.07]"
                  />
                  <span className="absolute inset-0 bg-gradient-to-t from-ink/75 via-ink/0 to-ink/0 opacity-0 transition-opacity duration-500 group-hover:opacity-100 group-focus-visible:opacity-100" />
                  <span className="absolute inset-x-0 bottom-0 flex translate-y-3 items-center justify-between p-4 text-cream opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100 group-focus-visible:translate-y-0 group-focus-visible:opacity-100 sm:p-5">
                    <span className="font-serif text-lg sm:text-xl">{item.caption}</span>
                    <Expand className="h-4 w-4 text-gold-soft" aria-hidden="true" />
                  </span>
                </button>
              </Reveal>
            );
          })}
        </ul>
      </div>

      {current && index !== null && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={current.caption}
          className="lightbox fixed inset-0 z-[60] flex items-center justify-center bg-ink/95 p-4 backdrop-blur-sm sm:p-10"
          onClick={close}
        >
          <figure className="relative flex max-h-full max-w-6xl flex-col items-center" onClick={(e) => e.stopPropagation()}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              key={current.image}
              src={imageSrc(current.image, 1920)}
              alt={current.alt}
              className="lightbox-img max-h-[78vh] w-auto rounded-[2px] object-contain shadow-2xl"
            />
            <figcaption className="mt-5 flex items-center gap-4 text-cream/80">
              <span className="font-serif text-xl text-cream">{current.caption}</span>
              <span className="text-xs tracking-[0.25em] text-cream/40 tabular-nums">
                {index + 1} / {gallery.length}
              </span>
            </figcaption>
          </figure>
          <button ref={closeRef} type="button" onClick={close} aria-label="Stäng" className="lb-btn absolute top-4 right-4 sm:top-6 sm:right-6">
            <X className="h-5 w-5" />
          </button>
          <button type="button" onClick={(e) => { e.stopPropagation(); step(-1); }} aria-label="Föregående bild" className="lb-btn absolute top-1/2 left-3 -translate-y-1/2 sm:left-6">
            <ChevronLeft className="h-5 w-5" />
          </button>
          <button type="button" onClick={(e) => { e.stopPropagation(); step(1); }} aria-label="Nästa bild" className="lb-btn absolute top-1/2 right-3 -translate-y-1/2 sm:right-6">
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      )}
    </section>
  );
}
