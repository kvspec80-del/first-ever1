import type { Metadata, Viewport } from "next";
import { Cormorant_Garamond, Manrope } from "next/font/google";
import { fullAddress, site } from "@/config/site";
import { menu } from "@/data/menu";
import { imageSrc } from "@/lib/images";
import "./globals.css";

const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  style: ["normal", "italic"],
  variable: "--font-cormorant",
  display: "swap",
});

const manrope = Manrope({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-manrope",
  display: "swap",
});

const title = `${site.name} – ${site.tagline} i ${site.city}`;

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: title, template: `%s | ${site.name}` },
  description: site.description,
  keywords: ["restaurang", "köksbar", site.city, "middag", "boka bord", "plankstek", "räkmacka", "after work", "julbord"],
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    locale: "sv_SE",
    url: site.url,
    siteName: site.name,
    title,
    description: site.description,
    images: [{ url: imageSrc("hero", 1200), width: 1200, height: 1600, alt: `${site.name} – köksbar` }],
  },
  twitter: { card: "summary_large_image", title, description: site.description },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#12110f",
  width: "device-width",
  initialScale: 1,
};

/** Strukturerad data så att Google förstår att det här är en restaurang. */
const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Restaurant",
  name: site.name,
  description: site.description,
  url: site.url,
  telephone: site.phone.href,
  servesCuisine: ["Svensk", "Bistro"],
  priceRange: "$$",
  acceptsReservations: "True",
  image: `${site.url}${imageSrc("hero", 1200)}`,
  address: {
    "@type": "PostalAddress",
    streetAddress: site.address.street,
    postalCode: site.address.postalCode,
    addressLocality: site.address.city,
    addressCountry: "SE",
  },
  sameAs: [site.social.instagram, site.social.facebook],
  hasMenu: {
    "@type": "Menu",
    name: "Kvällsmeny",
    hasMenuSection: {
      "@type": "MenuSection",
      name: "Kvällsmeny",
      hasMenuItem: menu.map((d) => ({
        "@type": "MenuItem",
        name: d.name,
        description: d.description,
        offers: { "@type": "Offer", price: d.price, priceCurrency: "SEK" },
      })),
    },
  },
  areaServed: fullAddress,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="sv" className={`${cormorant.variable} ${manrope.variable}`} suppressHydrationWarning>
      <head>
        {/* Aktiverar scroll-animationer endast när JavaScript körs */}
        <script dangerouslySetInnerHTML={{ __html: "document.documentElement.classList.add('js')" }} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
