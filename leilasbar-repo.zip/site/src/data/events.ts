import type { ImageName } from "@/lib/images";

export type RestaurantEvent = {
  /** Kort kategori, t.ex. "Säsong" eller "Temakväll". */
  tag: string;
  title: string;
  /** Fri text: "Varje torsdag", "Från 28 november", "[DATUM]" … */
  when: string;
  description: string;
  image: ImageName;
  alt: string;
  /** Valfri knapp. Utelämna för att visa "Ring och boka". */
  cta?: { label: string; href: string };
  /** Sätt till false för att dölja ett evenemang utan att radera det. */
  visible?: boolean;
};

/**
 * ─────────────────────────────────────────────────────────────
 *  DET HÄNDER HOS OSS
 *  Lägg till, ändra eller ta bort evenemang här. Ordningen i listan
 *  är ordningen på sidan. Den första visas lite större.
 * ─────────────────────────────────────────────────────────────
 */
export const events: RestaurantEvent[] = [
  {
    tag: "Säsong",
    title: "Julbord i köksbaren",
    when: "[DATUM – DATUM]",
    description:
      "Klassiska julrätter, sill, lax och varma favoriter i en ombonad miljö. Perfekt för företaget, familjen eller vänner. Begränsat antal platser – boka i god tid.",
    image: "event-christmas",
    alt: "Julgran med röda dekorationer",
  },
  {
    tag: "Temakväll",
    title: "Fredagskvällar vid baren",
    when: "Varje fredag",
    description:
      "Utvalda drinkar, små rätter och god stämning från tidig kväll. Kom förbi efter jobbet.",
    image: "event-evenings",
    alt: "Drink med apelsin vid en mörk bardisk",
  },
  {
    tag: "Säsongsmeny",
    title: "Havets säsong",
    when: "[PERIOD]",
    description:
      "Kocken lagar med det bästa från säsongen – färska skaldjur, fisk och kalla klassiker i en meny som byts ut löpande.",
    image: "event-seasonal",
    alt: "Färska skaldjur och fisk på is",
  },
  {
    tag: "Sällskap",
    title: "Fest & firande",
    when: "Hela året",
    description:
      "Födelsedag, kickoff eller avtackning? Vi hjälper dig med meny och upplägg för sällskap.",
    image: "event-celebrations",
    alt: "Vänner skålar med rött vin",
  },
];
