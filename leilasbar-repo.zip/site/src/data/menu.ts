import type { ImageName } from "@/lib/images";

export type Dish = {
  name: string;
  price: number;
  description: string;
  image: ImageName;
  alt: string;
  /** Liten etikett ovanför rättens namn, t.ex. "Husets favorit". */
  badge?: string;
  category: "Varmrätter" | "Från havet" | "Dessert";
};

/**
 * Kvällsmenyn. Den första rätten visas stort som "signaturrätt".
 * Ändra pris, text eller bild direkt här.
 */
export const menu: Dish[] = [
  {
    name: "Husets plankstek på oxfilé",
    price: 269,
    description:
      "Duchessepotatis, rödvinssås, bearnaisesås, toppad med stekta champinjoner och baconlindade haricots verts.",
    image: "plankstek",
    alt: "Saftig oxfilé serverad med grönsaker och rödvinssås",
    badge: "Husets signatur",
    category: "Varmrätter",
  },
  {
    name: "Husets schnitzel",
    price: 229,
    description:
      "Serveras med rödvinssås, stekt potatis, gröna ärtor, kapris, ansjovis och citron.",
    image: "schnitzel",
    alt: "Stekt kött med stekt potatis och gröna bönor",
    category: "Varmrätter",
  },
  {
    name: "Elefantöra",
    price: 229,
    description: "Serveras med grönsaker, pommes frites och kryddsmör.",
    image: "elefantora",
    alt: "Grillat kött med pommes frites och örter",
    category: "Varmrätter",
  },
  {
    name: "Fish & Chips",
    price: 239,
    description: "Serveras med husets remouladsås, sallad och pommes frites.",
    image: "fish-chips",
    alt: "Krispiga pommes frites med örter",
    category: "Från havet",
  },
  {
    name: "Husets räkmacka",
    price: 219,
    description:
      "Grovt bröd, sallad, tomater, gurka, handskalade räkor, rödlök, citron och dilldressing.",
    image: "rakmacka",
    alt: "Räkor med örter och citron",
    badge: "Klassiker",
    category: "Från havet",
  },
  {
    name: "Skaldjurspasta",
    price: 229,
    description:
      "Med räkor, kräftstjärtar, grönsaker och hummersås. Toppad med jungfrumix, minitomater och citron.",
    image: "skaldjurspasta",
    alt: "Pasta med räkor och tomater i stekpanna",
    category: "Från havet",
  },
  {
    name: "Husets kladdkaka",
    price: 69,
    description: "Serveras med grädde, hallonsås och färska jordgubbar.",
    image: "kladdkaka",
    alt: "Mörk chokladkaka i bitar",
    category: "Dessert",
  },
];
