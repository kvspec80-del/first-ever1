import type { ImageName } from "@/lib/images";

export type GalleryItem = {
  image: ImageName;
  alt: string;
  caption: string;
  /** Storlek i rutnätet: "big" (2×2), "wide" (2×1), "tall" (1×2) eller ingen (1×1). */
  span?: "big" | "wide" | "tall";
};

export const gallery: GalleryItem[] = [
  { image: "g-bar", alt: "Varmt upplyst bar med flaskor längs väggen", caption: "Baren", span: "big" },
  { image: "g-steak", alt: "Rosastekt kött som skärs upp", caption: "Från grillen", span: "wide" },
  { image: "g-chef", alt: "Kock som lägger upp tallrikar i köket", caption: "Köket", span: "tall" },
  { image: "g-pour", alt: "Drink som hälls upp i ett glas", caption: "Drinkar" },
  { image: "g-dining", alt: "Matsal med dukade bord och varm belysning", caption: "Matsalen", span: "wide" },
  { image: "g-shrimp", alt: "Vitlöksstekta räkor i gjutjärnspanna", caption: "Skaldjur" },
  { image: "g-flames", alt: "Kock vid spisen med lågor i köket", caption: "Med eld och omsorg", span: "wide" },
  { image: "g-berries", alt: "Dessert med färska jordgubbar i glas", caption: "Desserter", span: "tall" },
  { image: "g-room", alt: "Elegant matsal med dukade bord", caption: "Middag", span: "wide" },
  { image: "g-counter", alt: "Bardisk med varmt ljus", caption: "Kvällar vid disken", span: "tall" },
];
