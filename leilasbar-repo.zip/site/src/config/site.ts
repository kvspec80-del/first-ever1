/**
 * ─────────────────────────────────────────────────────────────
 *  RESTAURANGENS UPPGIFTER – byt ut alla [PLATSHÅLLARE] här.
 *  All kontaktinfo på hela webbplatsen hämtas från den här filen.
 * ─────────────────────────────────────────────────────────────
 */
export const site = {
  name: "LeilasBar",
  shortName: "LeilasBar",
  tagline: "Köksbar & Restaurang",
  city: "Lindome",
  description:
    "En avslappnad köksbar med vällagade klassiker, personlig service och en härlig atmosfär. Boka bord för middag, after work eller kvällar i gott sällskap.",

  /** Webbplatsens publika adress – används för SEO och delningslänkar. */
  url: "https://www.leilasbar.se",

  phone: {
    /** Visas för besökaren, t.ex. "08-123 456 78" */
    display: "031-99 27 72",
    /** Används i tel:-länken. Internationellt format utan mellanslag, t.ex. "+46812345678" */
    href: "+4631992772",
  },

  email: "[E-POST]",

  address: {
    street: "Elementvägen 1",
    postalCode: "437 36",
    city: "Lindome",
  },

  /** Öppettider – lägg till eller ta bort rader efter behov. */
  hours: [
    { days: "Måndag – Torsdag", time: "[ÖPPETTIDER]" },
    { days: "Fredag – Lördag", time: "[ÖPPETTIDER]" },
    { days: "Söndag", time: "[ÖPPETTIDER]" },
  ],

  social: {
    instagram: "https://www.instagram.com/[INSTAGRAM]",
    facebook: "https://www.facebook.com/[FACEBOOK]",
  },

  /**
   * Google Maps: klistra in "Bädda in karta"-länken (src-attributet) från Google Maps.
   * Lämna tom för att visa en snygg platshållare med länk till vägbeskrivning.
   */
  mapEmbedUrl: "",
} as const;

export const telHref = `tel:${site.phone.href}`;

export const fullAddress = `${site.address.street}, ${site.address.postalCode} ${site.address.city}`;

export const mapsSearchUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
  `${site.name} ${fullAddress}`,
)}`;

export const navItems = [
  { label: "Hem", href: "#hem" },
  { label: "Meny", href: "#meny" },
  { label: "Om oss", href: "#om-oss" },
  { label: "Galleri", href: "#galleri" },
  { label: "Kontakt", href: "#kontakt" },
] as const;
