import { imageMeta } from "./image-meta";

export type ImageName = keyof typeof imageMeta;

/** Bas-sökväg för bilderna. Kan ändras via NEXT_PUBLIC_IMAGE_BASE (t.ex. för ett CDN). */
export const IMAGE_BASE = process.env.NEXT_PUBLIC_IMAGE_BASE ?? "/images";

export function imageSrc(name: ImageName, width: number) {
  return `${IMAGE_BASE}/${name}-${width}.webp`;
}

export function imageSrcSet(name: ImageName) {
  return imageMeta[name].widths.map((w) => `${imageSrc(name, w)} ${w}w`).join(", ");
}

export function imageFallback(name: ImageName) {
  const widths = imageMeta[name].widths;
  return imageSrc(name, widths[Math.min(1, widths.length - 1)]);
}
